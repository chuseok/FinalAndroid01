package com.example.logintest.dialog;

public interface DragonDialogListener {
    void reviveDragon(int data);
    void cancel();
}
