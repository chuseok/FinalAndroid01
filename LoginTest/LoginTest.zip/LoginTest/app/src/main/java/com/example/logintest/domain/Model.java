package com.example.logintest.domain;

public class Model {

    private String id;
    private String title;
    private int desc;

    public Model(String title, int desc, String id) {
        this.title = title;
        this.desc = desc;
        this.id = id;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDesc() {
        return desc;
    }

    public void setDesc(int desc) {
        this.desc = desc;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
