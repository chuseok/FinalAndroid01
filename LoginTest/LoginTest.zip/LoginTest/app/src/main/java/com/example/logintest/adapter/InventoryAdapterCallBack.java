package com.example.logintest.adapter;

public interface InventoryAdapterCallBack {
    void setLevelValue(int data);
    void setFoodValue(int data);
    void setLevelText(int data);
    void setDotIndicator(int data);
    void setDragonImage(String path);
}
